package com.iot.nxt;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class IotNxtApplicationTests {

	@Test
	void contextLoads() {
	}

}
