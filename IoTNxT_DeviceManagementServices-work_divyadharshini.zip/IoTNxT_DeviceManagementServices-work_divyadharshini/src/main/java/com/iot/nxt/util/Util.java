package com.iot.nxt.util;

public class Util {

	public static boolean isNull(Object obj) {
		return obj == null;
	}
}
