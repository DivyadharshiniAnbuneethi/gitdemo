package com.iot.nxt.to.request;

import com.iot.nxt.entity.DemoEntity;

public class DemoRequest {
	
	private DemoEntity demoObj;

	public DemoEntity getDemoObj() {
		return demoObj;
	}

	public void setDemoObj(DemoEntity demoObj) {
		this.demoObj = demoObj;
	}
	
}
